//package parent;
//
//public class Main2 {
//    public static void main (String[] args) {
//        Human human1 = new Human ();
//        human1.name
//    }
//}
