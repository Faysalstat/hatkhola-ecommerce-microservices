package parent;

public class Human {
    public String name;
    public String nationality;
    public String height;



    public void sayHello(){
        System.out.println ("Hello, I am from Human Class");
    }
}
