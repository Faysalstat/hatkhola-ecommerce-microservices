package child;

import parent.Human;

public class Teacher extends Human {

    public String department;

}
